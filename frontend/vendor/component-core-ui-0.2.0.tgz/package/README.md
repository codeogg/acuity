# design-kit

The house design-system base: a code-first [shadcn](https://ui.shadcn.com) registry (`registry.json` + DTCG tokens + components + presets) that is the single source of truth for both a React component library and the matching Figma design system. Every product's design system is a controlled fork of this base – seed at a pinned version, re-theme, add small deltas – so projects share one foundation instead of each building a component library from scratch.

## What's in it

- **A 3-tier DTCG token graph** ([`tokens/`](tokens/)) – primitive (raw values) → semantic (role aliases, the theming seam) → component (component-scoped). Canonical source; `dist/` is generated.
- **A shadcn registry** ([`registry.json`](registry.json)) – 45 components, 5 composed blocks, 4 presets, plus utilities. Buildable with `npx shadcn build`, installable with `npx shadcn add`.
- **Multiple presets** – semantic-tier overlays on one shared component structure: `neutral` (default), `dusk`, `canvas`, `bloom`.
- **A Figma design system** – the same token/registry source authored into a Figma file (variables, component sets, styles), kept in lockstep with the code.

## Consuming the base

```sh
# install a component (and its tokens) from the built registry
npx shadcn@latest add <component>
```

A component arrives already bound to the token graph; swap the preset or the semantic overlay to re-theme without touching component structure.

## Packages & publishing

The design system publishes to npm as versioned packages (alongside the `shadcn add` registry flow), under one governing rule:

> **The generic base is public; everything project-specific is private — all under the one `@component-core` scope.**

- **`@component-core/ui`** (public) – the generic design-system base (components + a `./tokens.css` export). Install with `npm i @component-core/ui`; published versions are immutable. The npm scope is `component-core` because `@design-kit` was already taken on the registry — the repository/project keeps the name `design-kit`, the package publishes as `@component-core/ui`.
- **Every project-specific package is private, under the same `@component-core` scope.** Anything beyond the generic base — a product's theme overlay, its product-only components, any per-project delta — ships as a **private** `@component-core/<project>` package depending on `@component-core/ui`. No project gets its own npm org; they all live as private packages in `@component-core` (the org is on the paid plan for exactly this). Published so far: **`@component-core/acuity`** — Acuity's Caliber theme (private).

Publishing is on a version tag via the GitHub Action ([`.github/workflows/publish.yml`](.github/workflows/publish.yml)); the interim manual path is `npm publish` (use `npm`, not `pnpm` — `pnpm publish` mis-encodes the scope on a package's first publish and 404s).

## Structure

| Path | What |
|---|---|
| [`tokens/`](tokens/) | canonical DTCG tokens (tier 1-3) + `presets/` |
| [`src/components/ui/`](src/components/ui/) | component code (`registry:ui`) |
| [`src/blocks/`](src/blocks/) | composed blocks (`registry:block`) |
| [`registry.json`](registry.json) | the registry manifest (single origin for code + design) |
| [`scripts/`](scripts/) | token build, theme generation, registry build, verifier |
| [`docs/reference.md`](docs/reference.md) | the base spec: global-vs-project model, artefact set, completion criteria |
| [`docs/design/`](docs/design/) | the design-system docs + the Figma file record |
| [`docs/adr/`](docs/adr/) | decisions |

## Scripts

```sh
pnpm tokens          # build dist/ (tokens.css, tailwind theme, shadcn cssVars) from tokens/
pnpm tokens:verify   # determinism gate: aliases resolve, no tier skips, no restated literals
pnpm theme           # generate a brand primitive scale from a seed colour
pnpm registry        # build presets + the registry
pnpm build           # type-check + build the host app
```

## Licence

Seeded from MIT-licensed shadcn/ui + Radix primitives; every added dependency and asset is kept compatible with redistribution as a derivative.
